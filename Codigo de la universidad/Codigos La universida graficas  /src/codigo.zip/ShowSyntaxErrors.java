// ShowSyntaxErrors.java: The program contains syntax errors
package chapter2;

public class ShowSyntaxErrors {
  public static void main(String[] args) {
//    i = 30;
//    System.out.println(i + 4);
  }
}