// ComputeArea.java: Compute the area of a circle
package chapter2;

public class ComputeArea {
  /** Main method */
  public static void main(String[] args) {
    double radius;
    double area;
    
    // Assign a radius
    radius = 20;
    
    // Compute area
    area = radius * radius * 3.14159;
    
    // Display results
    System.out.println("The area for the circle of radius " +
      radius + " is " + area);
  }
}