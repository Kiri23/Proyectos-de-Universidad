// Welcome.java: This application program prints Welcome to Java!
package chapter1;

public class Welcome {
  public static void main(String[] args) {
    System.out.println("Welcome to Java!");
  }
}