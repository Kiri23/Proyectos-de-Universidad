package chapter10;

public class Node {
  Object element;
  Node next;

  public Node(Object o) {
    element = o;
  }
}